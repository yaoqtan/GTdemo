$(document).ready(function() {
	$('header')
	.css({ 'top':-70 })
	.animate({'top': 0}, 800);
	
	$('footer')
	.css({ 'bottom':-40 })
	.animate({'bottom': 0}, 800);
	
});