(function() {
  var COM;
  var URL = "pru.json";
  var MOB_WIDTH = 800;
  COM = {
    css_into:function(){
      $("body, ul, li, div, p, h1, table, th, tr, td, h4").css({
        "margin":0,
        "padding":0,
        "border":0
      });
      $("ul,li").css({
        "listStyle":"none",
        "textAlign":"center"
      })
     
     //wrap-time
     $(".wrap-time").css({
      "width":"15%",
      "display":"inline",
      "float":"left"
     });
     //#wrapper
     $("#wrapper").css({
      "position":"relative",
      "overflow":"hidden",
      "width":"84%",
      "float":"left",
      "display":"inline"
     });
     //#scroller
     $("#scroller").css({
      "width":"100%",
      "height":"100%",
      "overflow":"scroll"
     });
     //table
     $("table").css({
      "borderRight":"1px solid #ccc",
      "borderBottom":"1px solid #ccc",
      "width":"1050px"
     });
     $("th,td").css({
      "borderLeft":"1px solid #ccc",
      "borderTop":"1px solid #ccc",
      "width":"150px"
     });
     $("th").css("height","50px");
     $("th div").css({"fontSize":"20px","lineHeight":"100%","textAlign":"center"});
     $("th p").css({"fontSize":"16px","lineHeight":"100%","textAlign":"center"});
     /*$("td div").css({
      "minHeight":"60px",
      "margin":"1px 2px",
      "padding":"5px 0 5px 5px",
      "boxSizing":"border-box",
      "color":"#fff",
      "border":"1px soild #fff",
      "borderRadius":"5px",
      "lineHeight":"1",
      "background":"#4298ba"
     });*/
     $("td span").css({
      "display":"inline-block",
      "background":"#fff",
      "color":"#4298ba",
      "padding":"2px",
      "fontSize":"14px",
      "margin":"1px"
     });
     $("table tr").each(function(i){
        var trheight = $(this).height();
       $(".wrap-time").find("li").eq(i).css({
        "minHeight":"50px",
        "height":trheight,
        "lineHeight":"0px",
        "textAlign":" center"
       })
      
     });
     var tableheight = $("table").height();
     var ulheight = $(".wrap-time").height();
     if(ulheight > tableheight ){
        tableheight = ulheight;
     }
     $(".wrap").css({
      "width":"100%",
      "height":tableheight,
      //"overflowX":"hidden"
     });
    },
    Table_form:function(){
      var $ul = $(".wrap").find("ul");
      var $table = $(".wrap").find("table");
      $.ajax({
        url:URL,
        type:"GET",
        dataType:"json",
        success:function(data){
         var data = eval(data);
         var dataText = data.workingList
         var dataworking = dataText.working
         var worklength = dataworking.length;

         COM.Made_form(dataworking[0].startDateTime,dataworking[0].clientName,worklength)
         $.each(dataworking,function(index){
            //console.log(dataText.working[index].clientName)
            //console.log(dataworking[index].interviewType.name)
            //console.log(COM.DateTime(dataworking[index].startDateTime))
         });
         console.log("success")
        },
        error:function(){
          console.log("error")
        }
      });

      COM.css_into();
    },
    Made_form:function(time,name,worklength){
      var tr = "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"

      var datetime = time;
      var reg = / /;
      var reg1 = /-/
      var array = datetime.split(reg);
      var date = array[0];
      var time = array[1];
      var day = date.split(reg1)[2];

      var weekday = (new Date(date).getDay())
      /*alert(weekday)*/
      COM.initDate(date);

      for(var i = 0;i<worklength;i++){
       /* $("table").append(tr);
        $("table").find("td").css({
          "borderLeft":"1px solid #ccc",
          "borderTop":"1px solid #ccc",
          "width":"150px"
        });*/
      }

      var tddiv = $("table").find("tr").eq(1).find("td").eq(weekday-1).append("<div><h4></h4></div>");
      tddiv.find("div h4").html(name);
      tddiv.find("div").css({
        "minHeight":"60px",
        "margin":"1px 2px",
        "padding":"5px 0 5px 5px",
        "boxSizing":"border-box",
        "color":"#fff",
        "border":"1px soild #fff",
        "borderRadius":"5px",
        "lineHeight":"1",
        "background":"#4298ba"
      });
      tddiv.find("h4").css({
        "margin":0,
        "padding":0      
      })



    },
    initDate:function(date){
        var date = date;
        var aryDay = new Array("日","一","二","三","四","五","六");
        var currDT = new Date(date);

        var dw = currDT.getDay();//从Date对象返回一周中的某一天(0~6)
        var tdDT;//日期  

        //在表格中显示一周的日期  
        for(var i=0;i<7;i++) {
          tdDT = COM.getDays(date)[i];
          //console.log("tdDt:"+tdDT);
          dw = tdDT.getDay();
          //星期几
          $("th").eq(i).find("div").html(tdDT.getDate());
          $("th").eq(i).find("p").html(aryDay[dw])
        } 
      },//日期

    getDays:function(date){
      var date = date;
      var days = new Array();
      for(var i=1;i<=7;i++) {
        days[i-1] = COM.getWeek(i,date);
      }
      return days;
    },   
    getWeek:function(i,date){
      var now = new Date(date);
      var n = now.getDay();
      var start = new Date(date);
      start.setDate(now.getDate() - n + i);//取得一周内的第一天、第二天、第三天...
      return start;
    }

  };

  $(function() {
   
    COM.Table_form();
  });
}).call(this);



